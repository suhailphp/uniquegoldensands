
git reset --hard;
git pull origin master;

